library(shiny)

ui <- fluidPage(
  sliderInput('num', "Choose a number", 1, 100, 25),
  textInput('title', "Enter a title for plot"),
  numericInput('count', 'a number', 100, min=1, max=1000),
  plotOutput('hist'),
  plotOutput('unif')
)

server <- function(input, output, session) {
  output$hist <- renderPlot({
    hist(rnorm(input$num))
  })  
  
  output$unif <- renderPlot({
    hist(runif(input$num))
  })
  
  output$hist <- renderPlot({
    hist(rnorm(input$num), main = isolate(input$title))
  })  
}

shinyApp(ui, server)