library(shiny)

ui <- fluidPage(
  # regular text
  "Hello Shiny!",

  # HTML contents
  "Below is an unorder list:",
  tags$ul(
    tags$li('SDTM'),
    tags$li('ADaM'),
    tags$li('TLFs'),
  ),
  tags$blockquote('Everything that exists in R is an object -- John Chambers'),

  # different level of headers
  strong("Below is different level of headers"),
  h1("data step"),
  h2("Proc sort"),
  h3("Proc Means"),

  # customize the layout
  fluidRow(
    column(4,
      wellPanel(
        selectInput("sdtm", label = "SDTM Datasets", choices = c('DM', 'EX', 'VS', 'LB'))
      )       
    ),
    column(4,
      wellPanel(
        selectInput("adam", label = "SDTM Datasets", choices = c('ADAL', 'ADEX', 'ADVS', 'ADLB'))
      )
    ),
    column(4,
      wellPanel(
        selectInput("tlfs", label = "TLGs", choices = c('Safety', 'Subject Information', 'Efficacy'))
      )
    ),
  )
)

server <- function(input, output, session) {
  
}

shinyApp(ui, server)
