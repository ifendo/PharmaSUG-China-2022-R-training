library(shiny)

ui <- fluidPage(
  "hello, world!",
  h1("hello world")
)

server <- function(input, output, session) {
  
}

shinyApp(ui, server)

