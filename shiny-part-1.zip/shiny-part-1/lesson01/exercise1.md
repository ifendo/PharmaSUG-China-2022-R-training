Modified example "01_hello":

+ Change the title from “Hello Shiny!” to “Hello World!”.

+ Set the minimum value of the slider bar to 5.

+ Change the histogram border color from "white" to "orange"

