Just try playing with the sample applications and reviewing the source code to get an initial feel of the shiny apps.

## Now we have:
+ 11 shiny built-in examples
+ 6 demos from various sources
+ 6 examples from the RStudio Shiny Written Tutorials

## Where to find more resources
+ [Mastering Shiny](https://mastering-shiny.org/index.html)
+ [Shiny Dev Center](https://shiny.rstudio.com/)


**Happy learning and coding!!**


https://awsapxnva1052.jnj.com/user/jwang447/ap_r_initiative