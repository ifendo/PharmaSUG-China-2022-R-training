library(shiny)
library(clipr) # copy to clipboard

ui <- fluidPage(
  h3("This small app converts your Windows path to Linux format"),

  textInput('in_path', "Windows Path:", width = "80%"),
  textOutput('out_path'),
  actionButton('copy', "Copy to Clipboard!")
)

server <- function(input, output, session) {
  output$out_path <- renderText({
    req(input$in_path)
    
    gsub("\\", "/", input$in_path, fixed = TRUE )
  })
  
  observeEvent(input$copy, {
    req(input$in_path)
    
    write_clip(gsub("\\", "/", input$in_path, fixed = TRUE ),
                      allow_non_interactive = TRUE)
  })
}

shinyApp(ui, server)